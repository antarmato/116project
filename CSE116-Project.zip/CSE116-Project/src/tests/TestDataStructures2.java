package tests;


import org.junit.Test;
import ratings.Playlist;
import ratings.Song;
import ratings.SongTitleComparator;
import ratings.datastructures.Comparator;

public class TestDataStructures2 {
     @Test
    public void testPlaylist(){
        Playlist play = new Playlist(new SongTitleComparator());
        play.addSong(new Song("Gang","Anthony","Cd24-1dc"));


    }
}
