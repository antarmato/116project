package tests;

import org.junit.Test;
import ratings.*;
import ratings.datastructures.LinkedListNode;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;


public class TestClasses2 {

    @Test
    public void testBayesianAverageRating(){
        Song song = new Song("Dynamite", "BTS", "o-YBDTqX_ZU");

        song.addRating(new Rating("Jesse", 5));
        song.addRating(new Rating("Paul", 5));
        song.addRating(new Rating("Carl", 3));
        song.addRating(new Rating("Matt", 5));
        assertEquals(0,song.bayesianAverageRating(2,3),0.001);

        Song song2 = new Song("Ant","Awd","ad2ad");
        assertEquals(0,song.bayesianAverageRating(2,3),0.001);

    }

    @Test
    public void testMovie(){
        ArrayList<String> cast = new ArrayList<>(Arrays.asList("Anthony","Joe","Tom","Jerry"));
        Movie test = new Movie("Avengers",cast);
        assertTrue("Avengers".equals(test.getTitle()));
        assertTrue(cast.equals(test.getCast()));
        LinkedListNode<Rating> expected = new LinkedListNode<>(new Rating("Jesse", 3), null);
        expected = new LinkedListNode<>(new Rating("Paul", 4), expected);
        expected = new LinkedListNode<>(new Rating("Carl", 5), expected);

        Movie test2 = new Movie("Avengers", cast);
        test2.addRating(new Rating("Yuh",3));
        test2.addRating(new Rating("Paul", 2));
        test2.addRating(new Rating("Jesse", 1));
        assertEquals(0,test2.bayesianAverageRating(2,3),0.001);
    }
    @Test
    public void testSongTitleComparator(){
        Song song = new Song("Come As You Are", "Nirvana", "vabnZ9-ex7o");
        Song song2 = new Song("Dynamite", "BTS", "o-YBDTqX_ZU");

        SongTitleComparator compares = new SongTitleComparator();
        boolean yuh = compares.compare(song, song2);
        assertTrue(!yuh);
    }

    @Test
    public void testSongBayesianRatingComparator(){
        Song song = new Song("Come As You Are", "Nirvana", "vabnZ9-ex7o");
        Song song2 = new Song("Dynamite", "BTS", "o-YBDTqX_ZU");

        SongBayesianRatingComparator compares = new SongBayesianRatingComparator();
        boolean yuh = compares.compare(song, song2);
        assertTrue(!yuh);
    }
}
