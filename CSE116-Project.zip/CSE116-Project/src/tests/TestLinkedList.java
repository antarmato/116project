package tests;
import org.junit.Test;
import ratings.datastructures.LinkedListNode;

import static org.junit.Assert.*;

public class TestLinkedList {

    private void equalsLists(LinkedListNode<String> expected, LinkedListNode<String> actual){
        if(expected == null){
            assertNull(actual);
        } else{
            assertNotNull(actual);
            assertTrue(expected.getValue().equalsIgnoreCase(actual.getValue()));
            equalsLists(expected.getNext(),actual.getNext());
        }

    }


    @Test
    public void testLinkedLists(){
        LinkedListNode<String> list = null;
        list = new LinkedListNode<>("foo",null);
        //"foo"
        list.append("bar");
        //"foo" -> "bar"
        list.append("lorem");
        //"foo" -> "bar" -> "lorem"
        list.append("ipsum");
        //"foo" -> "bar" -> "lorem" -> "ipsum"

        assertEquals(4,list.size());
        assertEquals("foo bar lorem ipsum",list.toString());

        LinkedListNode<String> expected = new LinkedListNode<>("ipsum", null);
        //"ipsum"
        expected = new LinkedListNode<>("lorem",expected);
        // "lorem" -> "ipsum"
        expected = new LinkedListNode<>("bar",expected);
        // "bar" -> "lorem" -> "ipsum"
        expected = new LinkedListNode<>("foo",expected);
        // "foo" -> "bar" -> "lorem" -> "ipsum"

        equalsLists(expected,list);
    }
}
