package tests;

import org.junit.Test;
import ratings.ProblemSet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import java.util.Random;
public class TestProblemSet {
        private final double EPSILON = 0.001;
        public void compareDoubles(double d1,double d2){
            assertTrue(Math.abs(d1-d2)<EPSILON);
        }
        @Test
        public void testAverage(){
            ArrayList <Double> arr = new ArrayList<>(Arrays.asList(1.0,2.0,3.0));
            assertEquals(2.0,ratings.ProblemSet.average(arr),0.0001);
            ArrayList <Double> arr2 = new ArrayList<>(Arrays.asList(-5.0,5.0));
            assertEquals(0.0,ratings.ProblemSet.average(arr2),0.0001);
            ArrayList <Double> arr3 = new ArrayList<>(Arrays.asList(6.5,6.5,8.5,8.5));
            assertEquals(7.5,ratings.ProblemSet.average(arr3),0.0001);
            ArrayList <Double> arr4 = new ArrayList<>();
            assertEquals(0.0,ratings.ProblemSet.average(arr4),0.0001);
            ArrayList <Double> arr5 = new ArrayList<>(Arrays.asList(1.0));
            assertEquals(1.0,ratings.ProblemSet.average(arr5),0.0001);
            ArrayList <Double> arr6 = new ArrayList<>(Arrays.asList(30000.0,92.0,6000.0,0.8016,54.32,1242.231,124.151,1246.214,561.124,1512.125,151.512));
            assertEquals(3725.861690909091,ratings.ProblemSet.average(arr6),0.0001);




        }
        @Test
        public void testSumOfDigits() {
            assertTrue(ratings.ProblemSet.sumOfDigits(123)==6);
            assertTrue(ratings.ProblemSet.sumOfDigits(57)==12);
            assertTrue(ratings.ProblemSet.sumOfDigits(-36)==9);
        }
        @Test
        public void testBestKey(){
            HashMap<String, Integer> hash = new HashMap<>();
            hash.put("CSE",100);
            hash.put("MTH",90);
            hash.put("MGT",10);
            assertTrue(ratings.ProblemSet.bestKey(hash).equals("CSE"));

            HashMap<String, Integer> hash2 = new HashMap<>();
            hash2.put("dog",5);
            hash2.put("cat",5);
            hash2.put("fox",4);
            assertTrue(ratings.ProblemSet.bestKey(hash2).equals("cat")||ratings.ProblemSet.bestKey(hash2).equals("dog"));
            HashMap<String, Integer> hash3 = new HashMap<>();
            assertTrue(ratings.ProblemSet.bestKey(hash3).equals(""));

            HashMap<String, Integer> hash4 = new HashMap<>();
            hash4.put("dog",-2);
            hash4.put("cat",-4);
            hash4.put("fox",-5);
            assertTrue(ratings.ProblemSet.bestKey(hash4).equals("dog"));

        }
    // TODO: Write testing for all 3 methods of the ratings.ProblemSet class


}