package ratings;

import ratings.datastructures.Comparator;
import ratings.Song;

public class SongTitleComparator extends Comparator<Song>{

    public boolean compare(Song a, Song b) {
        return false;
    }

}
