package ratings;

public class Reviewer {
    private String reviewerID;

    public Reviewer(String reviewerID){
        this.setReviewerID(reviewerID);
    }

    public String getReviewerID(){
        return reviewerID;
    }

    public void setReviewerID(String reviewerID){
        this.reviewerID = reviewerID;
    }

    public Rating rateSong(int num){
        Rating rat = new Rating(reviewerID,num);
        return rat;
    }
}
