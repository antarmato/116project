package ratings;
import ratings.Song;
import ratings.datastructures.Comparator;

public class SongBayesianRatingComparator extends Comparator<Song>{

    public boolean compare(Song a, Song b){
        return false;
    }
}
