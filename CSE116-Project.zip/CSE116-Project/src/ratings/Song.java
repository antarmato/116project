package ratings;

import java.util.LinkedList;
import ratings.datastructures.LinkedListNode;
import java.util.Iterator;
public class Song {
    private String title, artist, songID;
    private LinkedListNode<Rating> list;

    public Song(String title, String artist, String songID) {
        this.title = title;
        this.artist = artist;
        this.songID = songID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getSongID() {
        return songID;
    }

    public void setSongID(String songID) {
        this.songID = songID;
    }

    public void addRating(Rating obj) {
        if (list == null) {
            list = new LinkedListNode<>(obj, null);
        } else {
            addRatingHelper(obj, list);//list.append(obj);
        }
    }

    public void addRatingHelper(Rating obj, LinkedListNode<Rating> list) {
        if (!didReviewerRateSong(obj.getReviewerID())) {
            list.append(obj);
        } else if (list.getNext() == null) {
        } else {
            addRatingHelper(obj, list.getNext());
        }

    }

    public LinkedListNode<Rating> getRatings() {
        return list;
    }

    public double averageRating() {
        if (list == null) {
            return 0.0;
        } else {
            return averageHelper(list, 0.0, 0);
        }
    }

    private double averageHelper(LinkedListNode<Rating> list, double sum, int size) {
        if (list == null) {
            return sum / size;
        } else {
            sum += list.getValue().getRating();
            size++;
            return averageHelper(list.getNext(), sum, size);
        }
    }

    public boolean didReviewerRateSong(String id) {
        if (list == null) {
            return false;
        } else {
            return didRRSHelper(id, list);
        }


    }

    private boolean didRRSHelper(String id, LinkedListNode<Rating> list) {
        if (list.getValue().getReviewerID().equals(id)) {
            return true;
        } else if (list.getNext() == null) {
            return false;
        } else {
            return didRRSHelper(id, list.getNext());
        }
    }

    public void removeRatingByReviewer(Reviewer obj) {
        removeRBRHelper(obj, list);

    }


    private void removeRBRHelper(Reviewer obj, LinkedListNode<Rating> list) {
        if(list.getValue().getReviewerID().equals(obj.getReviewerID())){
            this.list=list.getNext();
        }
        else if (list.getNext().getValue().getReviewerID().equals(obj.getReviewerID())) {
                list.setNext(list.getNext().getNext());
        }
        else {
            removeRBRHelper(obj, list.getNext());
        }

    }

    public double bayesianAverageRating(int num, int val){
        return 0.0;
    }
}


