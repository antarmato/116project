package ratings;

import ratings.datastructures.Comparator;
import ratings.datastructures.LinkedListNode;

public class Playlist {
    public Playlist(Comparator<Song> comparator) {
    }

    public void addSong(Song song){

    }

    public LinkedListNode<Song> getSongList(){
        return new LinkedListNode<Song>(new Song("yuh","Anthony","awd2"), null);
    }
}
