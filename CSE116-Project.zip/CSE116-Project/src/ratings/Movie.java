package ratings;

import ratings.datastructures.LinkedListNode;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Movie {
    String title;
    ArrayList<String> cast;

    public Movie(String title, ArrayList<String> cast){
        this.title = title;
        this.cast = cast;
    }

    public String getTitle(){
        return title;
    }

    public ArrayList<String> getCast(){
        return cast;
    }

    public void addRating(Rating obj) {

    }

    public double bayesianAverageRating(int num, int val){
        return 0.0;
    }

}
